./miner --algo 144_5 --pers BgoldPoW --server eu.pool.gold --port 3050 --user ANP4eJERuSsKufnm6JukyrFQ9NFTFXg4zX.test --pass x
